﻿namespace P01_StudentSystem
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            Console.WriteLine("Hello World!");
        }
    }
}
