﻿namespace Instagraph.DataProcessor.Dtos.Export
{
    public class UserDto
    {
        public string Username { get; set; }

        public int MostComments { get; set; } = 0;
    }
}
