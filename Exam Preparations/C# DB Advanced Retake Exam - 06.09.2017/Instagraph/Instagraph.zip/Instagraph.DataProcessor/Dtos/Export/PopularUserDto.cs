﻿namespace Instagraph.DataProcessor.Dtos.Export
{
    public class PopularUserDto
    {
        public string Username { get; set; }

        public int Followers { get; set; }
    }
}
