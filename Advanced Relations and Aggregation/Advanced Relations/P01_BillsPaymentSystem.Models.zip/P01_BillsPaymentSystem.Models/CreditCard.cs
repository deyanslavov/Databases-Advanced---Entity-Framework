﻿namespace P01_BillsPaymentSystem.Models
{
    using System;
    using System.Collections.Generic;

    public class CreditCard
    {
        public int CreditCardId { get; set; }

        public DateTime ExpirationDate { get; set; }

        public decimal Limit { get; set; }

        public decimal MoneyOwed { get; set; }

        public ICollection<PaymentMethod> PaymentMethods { get; set; }

        public decimal LimitLeft => this.Limit - this.MoneyOwed;
    }
}
