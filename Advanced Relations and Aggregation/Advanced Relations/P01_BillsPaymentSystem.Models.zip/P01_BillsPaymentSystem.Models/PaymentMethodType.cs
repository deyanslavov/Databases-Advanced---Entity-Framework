﻿namespace P01_BillsPaymentSystem.Models
{
    public enum PaymentMethodType
    {
        CreditCard,
        BankAccount
    }
}
